package com.example.deng;

import android.app.Activity;
import android.hardware.Camera;  
import android.hardware.Camera.Parameters;  
import android.os.Bundle;  
import android.view.View;  
import android.view.View.OnClickListener;  
import android.widget.Button;  
  
/** 
 * ����ƵĿ��� 
 * 
 * @author yang 
 */  

public class MainActivity extends Activity {
	 private Button open;  
	    private Button close;  
	    private Button openFlicker;  
	    private Button closeFlicker;  
	    private Camera camera;  
	    private Boolean isShanshuo;  
	  
	    @Override  
	    protected void onCreate(Bundle savedInstanceState) {  
	        super.onCreate(savedInstanceState);  
	        setContentView(R.layout.activity_main);  
	  
	        open = (Button) this.findViewById(R.id.open);  
	        close = (Button) this.findViewById(R.id.close);  
	        openFlicker = (Button) findViewById(R.id.openflash);  
	        closeFlicker = (Button) findViewById(R.id.closeflash);  
	  
	        open.setOnClickListener(openOnClickListener);  
	        close.setOnClickListener(closeOnClickListener);  
	        openFlicker.setOnClickListener(openFlickerOnClickListener);  
	        closeFlicker.setOnClickListener(closeFlickerOnClickListener);  
	    }  
	  
	    /** 
	     * ���ֵ�Ͳ 
	     */  
	    private OnClickListener openOnClickListener = new OnClickListener() {  
	        @Override  
	        public void onClick(View v) {  
	            open();  
	        }  
	    };  
	  
	    /** 
	     * �ر��ֵ�Ͳ 
	     */  
	    private OnClickListener closeOnClickListener = new OnClickListener() {  
	        @Override  
	        public void onClick(View v) {  
	            close();  
	        }  
	    };  
	  
	    /** 
	     * ������˸ 
	     */  
	    private OnClickListener openFlickerOnClickListener = new OnClickListener() {  
	        @Override  
	        public void onClick(View v) {  
	            isShanshuo = true;  
	            openFlicker.setEnabled(false);  
	            new Thread(new Runnable() {  
	                @Override  
	                public void run() {  
	                    while (isShanshuo) {  
	                    	//�����ʱ��
	                        open();  
	                        try {  
	                            Thread.sleep(500);  
	                        } catch (InterruptedException e) {  
	                            e.printStackTrace();  
	                        }  
	                        close(); 
	                        //���µ�ʱ��
	                        try {  
	                            Thread.sleep(80);  
	                        } catch (InterruptedException e) {  
	                            e.printStackTrace();  
	                        }  
	                    }  
	                }  
	            }).start();  
	        }  
	    };  
	  
	    /** 
	     * �ر���˸ 
	     */  
	    private OnClickListener closeFlickerOnClickListener = new OnClickListener() {  
	        @Override  
	        public void onClick(View v) {  
	            isShanshuo = false;  
	            openFlicker.setEnabled(true);  
	        }  
	    };  
	    /** 
	     * ������� 
	     * 
	     * @return 
	     */  
	    private void open() {  
	        try {  
	            camera = Camera.open();  
	            camera.startPreview();  
	            Parameters parameters = camera.getParameters();  
	            parameters.setFlashMode(Parameters.FLASH_MODE_TORCH);  
	            camera.setParameters(parameters);  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }  
	    }  
	    /** 
	     * �ر������ 
	     * 
	     * @return 
	     */  
	    private void close() {  
	        try {  
	            Parameters parameters = camera.getParameters();  
	            parameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);  
	            camera.setParameters(parameters);  
	            camera.release();  
	            camera = null;  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }  
	    }  
	
}
